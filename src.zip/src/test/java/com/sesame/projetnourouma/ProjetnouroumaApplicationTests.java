package com.sesame.projetnourouma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetnouroumaApplicationTests {

    @Test
    void contextLoads() {
    }

}
