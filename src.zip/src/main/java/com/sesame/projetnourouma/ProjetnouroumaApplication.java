package com.sesame.projetnourouma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetnouroumaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetnouroumaApplication.class, args);
    }

}
